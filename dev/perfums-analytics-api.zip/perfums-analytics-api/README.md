# Perfums Analytics API 2.0

Production API для автоматичного імпорту звітів 1С із Telegram у PostgreSQL/Supabase та читання даних через GPT Action.

## Що виправлено

- повторний файл із тим самим SHA-256 не імпортується вдруге;
- weekly виконує UPSERT лише наявних у файлі ключів і не видаляє весь діапазон;
- monthly транзакційно замінює весь календарний місяць;
- `data_month_status` блокує тижневі записи після фіналізації місяця;
- нові працівники, відділи й регіони створюються транзакційно;
- офіційні місячні показники беруться з `employee_monthly_performance`;
- зарплата та денна деталізація беруться з `payroll_daily`;
- додані статуси, задачі адміністраторів, фінальність місяця та денна зарплата;
- усі службові таблиці закриті RLS і не мають доступу для `anon/authenticated`.

Повні правила захисту від втрати даних: [IMPORT_SAFETY.md](IMPORT_SAFETY.md).

## Розгортання

1. Зробіть резервну копію БД Supabase.
2. У Supabase SQL Editor виконайте `sql/001_production_upgrade.sql`.
3. Замініть файли репозиторію в GitHub вмістом цієї папки та зробіть commit.
4. Дочекайтеся успішного deploy у Render.
5. Перевірте `/api/health` і логи Render.
6. У GPT Builder замініть Action-схему вмістом `openapi.yaml`.
7. Вставте інструкції з `GPT_INSTRUCTIONS.md`.
8. Виконайте контрольні запити з `DEPLOY_CHECKLIST.md`.

## Змінні Render

Скопіюйте назви з `.env.example`. Секрети ніколи не комітьте в GitHub.

## Локальна перевірка

```bash
npm ci
npm test
npm start
```

`npm test` має завершитися без помилок.
